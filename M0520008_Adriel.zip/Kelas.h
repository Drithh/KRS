#pragma once
#include <string>
#include <utility>
struct Kelas {
    std::string pengampu;
    int m_kuota;
    std::pair<int, int> m_jadwal;
};